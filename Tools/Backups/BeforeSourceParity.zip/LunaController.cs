using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

/// <summary>Standalone gameplay for the Playworks export; no original game framework dependencies.</summary>
public class LunaController : MonoBehaviour
{
    [Serializable] public class Zone
    {
        public string name;
        public Transform root, guardian;
        public Transform[] nests;
        public GameObject[] eggPrefabs, petPrefabs;
        public float guardianSpeed=7;
        [NonSerialized] public Vector3 guardianHome;
        [NonSerialized] public Quaternion guardianRotation;
        [NonSerialized] public Animator animator;
    }
    public enum TutorialStep { FindEgg, BringHome, Incubate, Hatch, Collect, Explore, Equip, Train }
    public Zone[] zones;
    public Transform player, home, safePoint;
    public Transform trainingPoint;
    public Camera gameCamera;
    public Animator playerAnimator;
    public Font uiFont;
    public Material guideMaterial;
    public Sprite roundedSprite, circleSprite;
    public AudioClip stealSound, deliverSound, hatchSound, caughtSound;
    public GameObject sourceHud;
    public int capturesForEndCard=3;
    public float moveSpeed=9, incubationSeconds=5;
    public string androidStoreUrl="", iosStoreUrl="";
    public TutorialStep Step {get; private set;}
    public int Delivered {get; private set;}
    public int Money {get; private set;}
    public bool IsCarrying {get{return carried!=null;}}
    public int BagCount {get{return bag.Count;}}
    public int PlacedPets {get{return pets.Count;}}
    public bool HasPendingPet {get{return pendingPet!=null;}}
    public bool EndCardVisible {get{return endCard && endCard.activeSelf;}}
    private class Egg
    {
        public Transform transform;
        public Vector3 origin, scale;
        public Quaternion rotation;
        public Zone zone;
        public int variant;
        public bool banked;
        public bool dropped, retrieved;
    }
    private readonly List<Egg> eggs=new List<Egg>();
    private readonly List<Transform> pets=new List<Transform>();
    private readonly List<Egg> bag=new List<Egg>();
    private Transform pendingPet;
    private bool tutorialCompleted, training;
    private float trainingClock;
    private int selectedZone;
    public bool IsKnockedDown {get{return hitZone!=null;}}
    public float hitWindup=.25f, knockdownDuration=1.6f, getUpDuration=.5f;
    private Zone hitZone;
    private float hitClock;
    private bool hitApplied;
    private Vector3 hitDirection,modelPosition;
    private Quaternion modelRotation,attackerRotation;
    private CharacterController motor;
    private Egg carried,nearby,incubating;
    private Transform carryPoint;
    private Vector3 spawn,cameraVelocity;
    private Quaternion spawnRotation;
    private float verticalSpeed,chaseDelay,catchCooldown,incubationEnd,incomeClock,messageUntil,yaw;
    private bool ended,sdkStarted,paused;
    private LineRenderer guide;
    private Text instruction,subtitle,moneyText,stageText,actionText,toast,hatchText,panelTitle,panelBody;
    private Button actionButton,dropButton;
    private GameObject endCard,panel;
    private RectTransform safeUI,hintHand;
    private PlayableJoystick joystick;
    private AudioSource sound;
    private bool muted;
    private readonly Color navy=new Color(.06f,.10f,.22f,.94f);

    private void Awake()
    {
        Luna.Unity.LifeCycle.OnPause+=Pause; Luna.Unity.LifeCycle.OnResume+=Resume;
        Luna.Unity.LifeCycle.OnMute+=Mute; Luna.Unity.LifeCycle.OnUnmute+=Unmute;
    }
    private void Start()
    {
        spawn=player.position;spawnRotation=player.rotation;
        sound=gameObject.AddComponent<AudioSource>();sound.playOnAwake=false;sound.volume=muted?0:.65f;
        motor=player.GetComponent<CharacterController>();
        if(!motor)motor=player.gameObject.AddComponent<CharacterController>();
        motor.height=2;motor.radius=.4f;motor.center=Vector3.up;
        carryPoint=new GameObject("Carried egg").transform;carryPoint.SetParent(player,false);
        carryPoint.localPosition=new Vector3(0,1.5f,1.1f);
        foreach(Zone zone in zones)
        {
            if(zone.guardian) {zone.guardianHome=zone.guardian.position;zone.guardianRotation=zone.guardian.rotation;zone.animator=zone.guardian.GetComponentInChildren<Animator>();}
            for(int n=0;n<zone.nests.Length;n++)
            {
                if(zone.eggPrefabs.Length==0)continue;
                GameObject obj=Instantiate(zone.eggPrefabs[n%zone.eggPrefabs.Length],zone.nests[n].position,Quaternion.identity);
                obj.name=zone.name+" Egg "+(n+1);DisablePhysics(obj);SetVisualSize(obj,1.6f);
                Egg egg=new Egg();egg.transform=obj.transform;egg.origin=obj.transform.position;egg.rotation=obj.transform.rotation;egg.scale=obj.transform.localScale;egg.zone=zone;egg.variant=n%zone.eggPrefabs.Length;eggs.Add(egg);
            }
        }
        guide=new GameObject("Tutorial route").AddComponent<LineRenderer>();guide.material=guideMaterial;
        guide.startWidth=.18f;guide.endWidth=.18f;guide.positionCount=2;guide.useWorldSpace=true;
        guide.startColor=new Color(1,.88f,.1f);guide.endColor=Color.white;
        BuildUI();SetStep(TutorialStep.FindEgg);
        gameCamera.transform.position=player.position+new Vector3(0,16,-18);gameCamera.transform.LookAt(player.position+Vector3.up);
        Luna.Unity.LifeCycle.GameLoaded();
    }
    private void OnDestroy()
    {
        Luna.Unity.LifeCycle.OnPause-=Pause;Luna.Unity.LifeCycle.OnResume-=Resume;
        Luna.Unity.LifeCycle.OnMute-=Mute;Luna.Unity.LifeCycle.OnUnmute-=Unmute;
    }
    private void Pause(){paused=true;}
    private void Resume(){paused=false;}
    private void Mute(){muted=true;if(sound)sound.volume=0;}
    private void Unmute(){muted=false;if(sound)sound.volume=.65f;}
    private void PlaySound(AudioClip clip){if(sound && clip)sound.PlayOneShot(clip);}
    private void Update()
    {
        if(!player || paused)return;
        UpdateSafeArea();
        if(!EndCardVisible && !panel.activeSelf)
        {
            if(IsKnockedDown)UpdateKnockdown();else if(training)UpdateTraining();else MovePlayer();
            if(!IsKnockedDown)UpdateInteraction();UpdateGuardians();
            if(Input.GetKeyDown(KeyCode.E))Interact();if(Input.GetKeyDown(KeyCode.Q))DropEgg();
        }
        else if(playerAnimator)playerAnimator.SetFloat("Forward",0);
        UpdateIncubation();UpdateGuide();
        incomeClock+=Time.deltaTime;
        if(incomeClock>=1 && pets.Count>0){Money+=pets.Count*5;incomeClock=0;}
        moneyText.text="$ "+Money;
        if(Time.time>messageUntil)toast.text="";
        hintHand.anchoredPosition=new Vector2(Mathf.Sin(Time.time*2)*25,-30+Mathf.Cos(Time.time*2)*20);
    }
    private void LateUpdate()
    {
        if(!player || paused)return;
        if(Input.GetMouseButton(1))yaw+=Input.GetAxis("Mouse X")*3;
        Vector3 target=player.position+Vector3.up*1.5f;
        Vector3 desired=target+Quaternion.Euler(42,yaw,0)*new Vector3(0,0,Screen.height>Screen.width?-21:-17);
        gameCamera.transform.position=Vector3.SmoothDamp(gameCamera.transform.position,desired,ref cameraVelocity,.15f);gameCamera.transform.LookAt(target);
    }
    private void MovePlayer()
    {
        Vector2 input=Vector2.ClampMagnitude(joystick.Value+new Vector2(Input.GetAxisRaw("Horizontal"),Input.GetAxisRaw("Vertical")),1);
        if(input.sqrMagnitude>.01f && !sdkStarted){sdkStarted=true;Luna.Unity.LifeCycle.GameStarted();Track("first_move",1);hintHand.gameObject.SetActive(false);}
        Vector3 forward=gameCamera.transform.forward;forward.y=0;forward.Normalize();
        Vector3 right=gameCamera.transform.right;right.y=0;right.Normalize();
        Vector3 direction=forward*input.y+right*input.x;
        if(direction.sqrMagnitude>.01f)player.rotation=Quaternion.Slerp(player.rotation,Quaternion.LookRotation(direction),Time.deltaTime*14);
        if(motor.isGrounded && verticalSpeed<0)verticalSpeed=-2;
        verticalSpeed-=25*Time.deltaTime;motor.Move((direction*moveSpeed+Vector3.up*verticalSpeed)*Time.deltaTime);
        if(player.position.y< -12)Respawn();
        if(playerAnimator)
        {
            playerAnimator.SetFloat("Forward",input.magnitude);playerAnimator.SetFloat("MoveSpeed",input.magnitude);playerAnimator.SetBool("OnGround",motor.isGrounded);
            int layer=playerAnimator.GetLayerIndex("Stealing");if(layer>=0)playerAnimator.SetLayerWeight(layer,IsCarrying?1:0);
        }
    }
    private void UpdateInteraction()
    {
        nearby=null;float best=3.4f;
        foreach(Egg egg in eggs)if(!egg.banked && !egg.retrieved && egg!=carried && egg.transform)
        {float d=FlatDistance(player.position,egg.transform.position);if(d<best){best=d;nearby=egg;}}
        bool atHome=FlatDistance(player.position,home.position)<5.5f;
        if(IsCarrying && player.position.z<=safePoint.position.z)GatherEgg();
        if(training)SetAction("STOP TRAINING",true);
        else if(pendingPet && atHome)SetAction("EQUIP PET",true);
        else if(!IsCarrying && bag.Count>0 && atHome && incubating==null)SetAction("INCUBATE",true);
        else if(IsCarrying)SetAction("BRING IT HOME",false);
        else if(incubating!=null && Time.time>=incubationEnd && atHome)SetAction("HATCH!",true);
        else if(trainingPoint && FlatDistance(player.position,trainingPoint.position)<3)SetAction("TRAIN",true);
        else if(nearby!=null && !pendingPet)SetAction("STEAL",true);
        else SetAction("",false);
        dropButton.gameObject.SetActive(IsCarrying);
    }
    private void SetAction(string value,bool enabled){actionButton.gameObject.SetActive(value!="");actionButton.interactable=enabled;actionText.text=value;}
    public void Interact()
    {
        if(paused || IsKnockedDown || EndCardVisible || panel.activeSelf)return;
        if(training){training=false;return;}
        if(pendingPet && FlatDistance(player.position,home.position)<5.5f){EquipPet();return;}
        if(!IsCarrying && bag.Count>0 && FlatDistance(player.position,home.position)<5.5f && incubating==null){Incubate();return;}
        if(incubating!=null && Time.time>=incubationEnd && FlatDistance(player.position,home.position)<5.5f){Hatch();return;}
        if(!IsCarrying && trainingPoint && FlatDistance(player.position,trainingPoint.position)<3){BeginTraining();return;}
        if(!IsCarrying && !pendingPet && nearby!=null && !nearby.banked && !nearby.retrieved)TakeEgg(nearby);
    }
    private void TakeEgg(Egg egg)
    {
        carried=egg;egg.dropped=false;carried.transform.SetParent(carryPoint,false);carried.transform.localPosition=Vector3.zero;carried.transform.localRotation=Quaternion.identity;
        chaseDelay=Time.time+.75f;Track("egg_stolen",Array.IndexOf(zones,egg.zone)+1);SetStep(TutorialStep.BringHome);Notify("THE GUARD IS COMING! RUN HOME!");
        PlaySound(stealSound);
    }
    public void DropEgg()
    {
        if(!IsCarrying)return;
        carried.transform.SetParent(null);carried.transform.position=player.position+player.forward;
        carried.transform.rotation=carried.rotation;carried.dropped=true;carried=null;
        SetStep(TutorialStep.FindEgg);Notify("Egg dropped! The guardian will retrieve it.");
    }
    private void RestoreEgg(Egg egg){egg.transform.SetParent(null);egg.transform.position=egg.origin;egg.transform.rotation=egg.rotation;egg.transform.localScale=egg.scale;egg.dropped=false;egg.retrieved=false;egg.transform.gameObject.SetActive(true);}
    private void GatherEgg()
    {
        Egg egg=carried;carried=null;egg.banked=true;egg.transform.SetParent(null);egg.transform.gameObject.SetActive(false);bag.Add(egg);
        Delivered++;Track("egg_delivered",Delivered);PlaySound(deliverSound);SetStep(TutorialStep.Incubate);Notify("EGG SAVED TO YOUR BAG! Take it to your coop.");
    }
    private void Incubate()
    {
        if(incubating!=null){Notify("Hatch the egg in your coop first!");return;}
        if(bag.Count==0)return;
        incubating=bag[0];bag.RemoveAt(0);incubating.transform.gameObject.SetActive(true);incubating.transform.position=home.position+Vector3.up*.4f;
        incubationEnd=Time.time+incubationSeconds;SetStep(TutorialStep.Hatch);
        PlaySound(deliverSound);
    }
    private void UpdateIncubation()
    {
        if(incubating==null){hatchText.text="";return;}
        float left=Mathf.Max(0,incubationEnd-Time.time);hatchText.text=left>0?"HATCHING  "+Mathf.CeilToInt(left)+"s":"YOUR PET IS READY!";
        incubating.transform.localRotation=Quaternion.Euler(0,Time.time*20,Mathf.Sin(Time.time*8)*3);
    }
    private void Hatch()
    {
        Zone zone=incubating.zone;
        if(zone.petPrefabs.Length>0)
        {
            GameObject pet=Instantiate(zone.petPrefabs[incubating.variant%zone.petPrefabs.Length]);DisablePhysics(pet);SetVisualSize(pet,2.5f);
            pendingPet=pet.transform;pendingPet.SetParent(carryPoint,false);pendingPet.localPosition=Vector3.zero;
        }
        incubating.banked=false;RestoreEgg(incubating);
        Destroy(incubating.transform.gameObject);
        incubating.variant=(incubating.variant+1)%zone.eggPrefabs.Length;
        GameObject refill=Instantiate(zone.eggPrefabs[incubating.variant],incubating.origin,incubating.rotation);
        DisablePhysics(refill);SetVisualSize(refill,1.6f);incubating.transform=refill.transform;incubating.scale=refill.transform.localScale;incubating=null;
        Track("egg_hatched",Delivered);SetStep(TutorialStep.Equip);Notify("NEW PET! Place it in your coop to earn income.");
        PlaySound(hatchSound);
    }
    private void EquipPet()
    {
        pendingPet.SetParent(null);pendingPet.position=home.position+new Vector3((pets.Count%3-1)*2,0,2+(pets.Count/3)*2);
        pets.Add(pendingPet);pendingPet=null;Track("pet_equipped",pets.Count);
        SetStep(tutorialCompleted?TutorialStep.Explore:TutorialStep.Train);
        if(tutorialCompleted && pets.Count>=capturesForEndCard)ShowEndCard();
    }
    private void BeginTraining()
    {
        training=true;trainingClock=0;motor.enabled=false;player.position=trainingPoint.position;player.rotation=trainingPoint.rotation;motor.enabled=true;
        joystick.ResetInput();Track("training_started",1);
    }
    private void UpdateTraining()
    {
        if(joystick.Value.sqrMagnitude>.05f || Input.GetAxisRaw("Horizontal")!=0 || Input.GetAxisRaw("Vertical")!=0){training=false;return;}
        if(playerAnimator)playerAnimator.SetFloat("Forward",1);
        trainingClock+=Time.deltaTime;
        if(trainingClock>=1){trainingClock-=1;moveSpeed+=.1f;Notify("SPEED +0.1");
            if(Step==TutorialStep.Train){tutorialCompleted=true;SetStep(TutorialStep.Explore);Track("tutorial_completed",1);}}
    }
    private void UpdateGuardians()
    {
        foreach(Zone zone in zones)
        {
            if(!zone.guardian)continue;
            if(hitZone==zone)continue;
            bool chasing=IsCarrying && carried.zone==zone && Time.time>chaseDelay && Time.time>catchCooldown;
            Egg dropped=null;
            foreach(Egg egg in eggs)if(egg.zone==zone && egg.dropped && !egg.retrieved){dropped=egg;break;}
            Vector3 destination=chasing?player.position:dropped!=null?dropped.transform.position:zone.guardianHome;destination.y=zone.guardian.position.y;
            float distance=FlatDistance(zone.guardian.position,destination);
            if(distance>.3f)
            {
                zone.guardian.rotation=Quaternion.Slerp(zone.guardian.rotation,Quaternion.LookRotation(destination-zone.guardian.position),Time.deltaTime*6);
                float speed=chasing?(moveSpeed<zone.guardianSpeed || distance>6?zone.guardianSpeed*2:moveSpeed):zone.guardianSpeed*4;
                zone.guardian.position=Vector3.MoveTowards(zone.guardian.position,destination,speed*Time.deltaTime);
            }
            else if(!chasing)zone.guardian.rotation=zone.guardianRotation;
            if(zone.animator)SetAnimatorMovement(zone.animator,distance>.3f?1:0);
            if(!chasing && dropped!=null && distance<1){dropped.retrieved=true;dropped.transform.gameObject.SetActive(false);}
            if(!chasing && dropped==null && distance<.4f)foreach(Egg egg in eggs)if(egg.zone==zone && egg.retrieved)RestoreEgg(egg);
            if(chasing && distance<1.6f && !IsKnockedDown)BeginKnockdown(zone);
        }
    }
    private void BeginKnockdown(Zone zone)
    {
        hitZone=zone;hitClock=0;hitApplied=false;training=false;joystick.ResetInput();
        hitDirection=player.position-zone.guardian.position;hitDirection.y=0;
        if(hitDirection.sqrMagnitude<.01f)hitDirection=zone.guardian.forward;
        hitDirection.Normalize();zone.guardian.rotation=Quaternion.LookRotation(hitDirection);attackerRotation=zone.guardian.rotation;
        if(playerAnimator){modelPosition=playerAnimator.transform.localPosition;modelRotation=playerAnimator.transform.localRotation;playerAnimator.SetFloat("Forward",0);}
        SetAction("",false);dropButton.gameObject.SetActive(false);
    }
    private void UpdateKnockdown()
    {
        hitClock+=Time.deltaTime;
        // The source guardian only has locomotion clips: use a short strike lean for the attack.
        float strike=Mathf.Sin(Mathf.Clamp01(hitClock/(hitWindup+.2f))*Mathf.PI)*24;
        hitZone.guardian.rotation=attackerRotation*Quaternion.Euler(strike,0,0);
        if(hitClock<hitWindup)return;
        if(!hitApplied)
        {
            hitApplied=true;DropEgg();PlaySound(caughtSound);Track("caught",1);
            if(playerAnimator)playerAnimator.enabled=false;
            Notify("OUCH! You dropped the egg.");verticalSpeed=3;
        }
        float elapsed=hitClock-hitWindup;
        float rise=Mathf.Clamp01((elapsed-knockdownDuration)/getUpDuration);
        float fall=Mathf.Clamp01(elapsed/.25f)*(1-rise);
        if(playerAnimator)
        {
            Vector3 localDirection=player.InverseTransformDirection(hitDirection);
            Vector3 axis=Vector3.Cross(Vector3.up,localDirection);
            playerAnimator.transform.localRotation=Quaternion.AngleAxis(85*fall,axis)*modelRotation;
            playerAnimator.transform.localPosition=modelPosition+Vector3.up*(.3f*fall);
        }
        if(motor.isGrounded && verticalSpeed<0)verticalSpeed=-2;
        verticalSpeed-=20*Time.deltaTime;
        motor.Move((hitDirection*(elapsed<.4f?5*(1-elapsed/.4f):0)+Vector3.up*verticalSpeed)*Time.deltaTime);
        if(rise>=1)
        {
            if(playerAnimator){playerAnimator.transform.localPosition=modelPosition;playerAnimator.transform.localRotation=modelRotation;playerAnimator.enabled=true;}
            hitZone.guardian.rotation=attackerRotation;hitZone=null;catchCooldown=Time.time+2;verticalSpeed=0;
            // Preserve player position: recovering from a hit never teleports to spawn.
            SetStep(bag.Count>0?TutorialStep.Incubate:TutorialStep.FindEgg);
        }
    }
    private void Respawn(){motor.enabled=false;player.position=spawn;player.rotation=spawnRotation;motor.enabled=true;verticalSpeed=0;if(IsCarrying)DropEgg();}
    private void UpdateGuide()
    {
        Vector3 target=home.position;
        if(Step==TutorialStep.FindEgg || Step==TutorialStep.Explore)
        {
            float best=float.MaxValue;
            foreach(Egg egg in eggs)if(!egg.banked && !egg.retrieved && egg.transform && (tutorialCompleted?egg.zone==zones[selectedZone]:egg==eggs[0])){float d=FlatDistance(player.position,egg.transform.position);if(d<best){best=d;target=egg.transform.position;}}
        }
        if(Step==TutorialStep.BringHome)target=safePoint.position;
        if(Step==TutorialStep.Train && trainingPoint)target=trainingPoint.position;
        guide.enabled=!EndCardVisible && !IsKnockedDown && Step!=TutorialStep.Collect;
        guide.SetPosition(0,player.position+Vector3.up*.2f);guide.SetPosition(1,new Vector3(target.x,player.position.y+.2f,target.z));
    }
    private void SetStep(TutorialStep step)
    {
        Step=step;
        string[] titles={"STEAL AN EGG!","RUN TO THE SAFE ZONE!","INCUBATE YOUR EGG","HATCH YOUR FIRST PET!","YOUR PET EARNS COINS!","EXPLORE THE NEXT ZONE","PLACE YOUR PET IN THE COOP","TRAIN TO RUN FASTER"};
        string[] details={"Follow the line to the first nest. Tap STEAL.","Cross the safe line to save your egg in your bag.","Your egg is safe. Go to your coop and tap INCUBATE.","Wait for the egg, then tap HATCH.","Pets in your coop generate income.","Train at home, then steal eggs from stronger guardians.","Tap EQUIP PET inside your coop.","Follow the line to your treadmill. Tap TRAIN."};
        instruction.text=titles[(int)step];subtitle.text=details[(int)step];stageText.text="BAG  "+bag.Count+"   PETS  "+pets.Count;Track("tutorial_step",(int)step+1);
    }
    private void Notify(string message){toast.text=message;messageUntil=Time.time+3.5f;}
    private void Track(string name,int value){Luna.Unity.Analytics.LogEvent(name,value);}
    public void ShowEndCard(){endCard.SetActive(true);joystick.ResetInput();if(!ended){ended=true;Luna.Unity.LifeCycle.GameEnded();}}
    public void Install(){Track("install_clicked",1);Luna.Unity.Playable.InstallFullGame(androidStoreUrl,iosStoreUrl);}
    public void TravelToZone(int index)
    {
        if(IsCarrying){Notify("Bring your egg home before travelling.");return;}
        if(!tutorialCompleted){Notify("Finish the tutorial first.");return;}
        if(index<0 || index>=zones.Length)return;
        selectedZone=index;panel.SetActive(false);SetStep(TutorialStep.Explore);Notify("Follow the route to "+zones[index].name);
    }
    public void UpgradeSpeed(){if(IsKnockedDown || IsCarrying)return;SetStep(TutorialStep.Train);Notify("Use your treadmill at home to gain speed.");}
    private static float FlatDistance(Vector3 a,Vector3 b){a.y=0;b.y=0;return Vector3.Distance(a,b);}
    public static void DisablePhysics(GameObject obj)
    {
        foreach(Collider c in obj.GetComponentsInChildren<Collider>(true))c.enabled=false;
        foreach(Rigidbody body in obj.GetComponentsInChildren<Rigidbody>(true)){body.isKinematic=true;body.useGravity=false;}
        foreach(Transform t in obj.GetComponentsInChildren<Transform>(true))if(t.name.ToLowerInvariant().Contains("highlight"))t.gameObject.SetActive(false);
        foreach(TMPro.TMP_Text label in obj.GetComponentsInChildren<TMPro.TMP_Text>(true))label.gameObject.SetActive(false);
    }
    public static void SetVisualSize(GameObject obj,float height)
    {
        bool found=false;Bounds bounds=new Bounds();
        foreach(Renderer r in obj.GetComponentsInChildren<Renderer>())if(!(r is ParticleSystemRenderer) && !(r is LineRenderer))
        {if(!found){bounds=r.bounds;found=true;}else bounds.Encapsulate(r.bounds);}
        if(found && bounds.size.y>.01f)obj.transform.localScale*=height/bounds.size.y;
    }
    private static void SetAnimatorMovement(Animator a,float value)
    {
        foreach(AnimatorControllerParameter p in a.parameters)
        {
            if(p.type==AnimatorControllerParameterType.Float && (p.name=="Forward" || p.name=="Speed" || p.name=="MoveSpeed"))a.SetFloat(p.name,value);
            if(p.type==AnimatorControllerParameterType.Bool && (p.name=="IsMoving" || p.name=="Run"))a.SetBool(p.name,value>0);
        }
    }
    private void BuildUI()
    {
        if(!FindObjectOfType<EventSystem>())new GameObject("EventSystem",typeof(EventSystem),typeof(StandaloneInputModule));
        GameObject go=new GameObject("Playable UI",typeof(Canvas),typeof(CanvasScaler),typeof(GraphicRaycaster));
        Canvas canvas=go.GetComponent<Canvas>();canvas.renderMode=RenderMode.ScreenSpaceOverlay;canvas.sortingOrder=100;
        CanvasScaler scaler=go.GetComponent<CanvasScaler>();scaler.uiScaleMode=CanvasScaler.ScaleMode.ScaleWithScreenSize;scaler.referenceResolution=new Vector2(720,1280);scaler.matchWidthOrHeight=.5f;
        safeUI=Rect("Safe area",go.transform,Vector2.zero,Vector2.one);
        RectTransform banner=Box("Tutorial",safeUI,new Vector2(.03f,.83f),new Vector2(.97f,.96f),navy);
        instruction=Label("Instruction",banner,"",29,new Vector2(.03f,.43f),new Vector2(.97f,.92f));
        subtitle=Label("Details",banner,"",18,new Vector2(.04f,.05f),new Vector2(.96f,.43f));
        RectTransform money=Box("Coins",safeUI,new Vector2(.03f,.765f),new Vector2(.32f,.82f),new Color(.1f,.45f,.15f,.95f));
        moneyText=Label("Coins",money,"$ 0",30,Vector2.zero,Vector2.one);
        stageText=Label("Progress",safeUI,"",21,new Vector2(.36f,.765f),new Vector2(.97f,.82f));
        ButtonText("Zones",safeUI,"MAP",new Vector2(.03f,.67f),new Vector2(.20f,.735f),()=>OpenPanel("MAP"));
        ButtonText("Pets",safeUI,"PETS",new Vector2(.03f,.59f),new Vector2(.20f,.655f),()=>OpenPanel("PETS"));
        ButtonText("Speed",safeUI,"SPEED +",new Vector2(.78f,.67f),new Vector2(.97f,.735f),UpgradeSpeed);
        ButtonText("Shop",safeUI,"SHOP",new Vector2(.80f,.59f),new Vector2(.97f,.655f),()=>OpenPanel("SHOP"));
        toast=Label("Notification",safeUI,"",23,new Vector2(.04f,.48f),new Vector2(.96f,.57f));
        hatchText=Label("Incubation",safeUI,"",25,new Vector2(.1f,.40f),new Vector2(.9f,.46f));
        RectTransform pad=Box("Joystick",safeUI,new Vector2(.06f,.08f),new Vector2(.32f,.23f),new Color(1,1,1,.2f));
        RectTransform knob=Box("Knob",pad,new Vector2(.3f,.3f),new Vector2(.7f,.7f),new Color(1,1,1,.65f));
        pad.GetComponent<Image>().sprite=circleSprite;pad.GetComponent<Image>().type=Image.Type.Simple;pad.GetComponent<Image>().preserveAspect=true;
        knob.GetComponent<Image>().sprite=circleSprite;knob.GetComponent<Image>().type=Image.Type.Simple;knob.GetComponent<Image>().preserveAspect=true;
        joystick=pad.gameObject.AddComponent<PlayableJoystick>();joystick.knob=knob;
        hintHand=Label("Drag hint",pad,"DRAG",19,Vector2.zero,Vector2.one).rectTransform;
        actionButton=ButtonText("Action",safeUI,"STEAL",new Vector2(.64f,.11f),new Vector2(.96f,.22f),Interact);actionText=actionButton.GetComponentInChildren<Text>();actionButton.GetComponent<Image>().color=new Color(.20f,.75f,.19f);
        dropButton=ButtonText("Drop",safeUI,"DROP",new Vector2(.73f,.25f),new Vector2(.95f,.30f),DropEgg);
        Label("Controls",safeUI,"DRAG TO MOVE  |  WASD / E ON DESKTOP",15,new Vector2(.03f,.02f),new Vector2(.97f,.055f));
        panel=Box("Menu",safeUI,new Vector2(.04f,.20f),new Vector2(.96f,.80f),navy).gameObject;
        panelTitle=Label("Title",panel.transform,"",30,new Vector2(.05f,.87f),new Vector2(.8f,.98f));panelBody=Label("Body",panel.transform,"",22,new Vector2(.07f,.58f),new Vector2(.93f,.85f));
        ButtonText("Close",panel.transform,"X",new Vector2(.85f,.89f),new Vector2(.97f,.98f),()=>panel.SetActive(false));
        for(int i=0;i<zones.Length;i++){int index=i;int row=i/2,col=i%2;ButtonText("Zone_"+i,panel.transform,(i+1)+"  "+zones[i].name,new Vector2(.05f+col*.47f,.75f-row*.12f),new Vector2(.48f+col*.47f,.85f-row*.12f),()=>TravelToZone(index));}
        ButtonText("MenuInstall",panel.transform,"PLAY THE FULL GAME",new Vector2(.1f,.08f),new Vector2(.9f,.20f),Install);panel.SetActive(false);
        endCard=Box("End card",safeUI,Vector2.zero,Vector2.one,new Color(.025f,.05f,.12f,.96f)).gameObject;
        Label("Victory",endCard.transform,"EGG-CELLENT!",49,new Vector2(.05f,.64f),new Vector2(.95f,.78f));
        Label("Pitch",endCard.transform,"Build your collection.\nOutrun every guardian!",27,new Vector2(.1f,.46f),new Vector2(.9f,.62f));
        ButtonText("Install",endCard.transform,"PLAY NOW",new Vector2(.16f,.28f),new Vector2(.84f,.40f),Install).GetComponent<Image>().color=new Color(.18f,.76f,.18f);
        ButtonText("Continue",endCard.transform,"KEEP EXPLORING",new Vector2(.22f,.17f),new Vector2(.78f,.24f),()=>endCard.SetActive(false));endCard.SetActive(false);
        ApplySourceArt();
    }
    private void ApplySourceArt()
    {
        if(!sourceHud)return;
        GameObject art=Instantiate(sourceHud,safeUI,false);art.name="Original game HUD";art.SetActive(true);
        Transform[] all=art.GetComponentsInChildren<Transform>(true);
        CopyControlArt(all,"Button_Index","Pets",()=>OpenPanel("PETS"));
        CopyControlArt(all,"Button_IAPShop","Shop",()=>OpenPanel("SHOP"));
        CopyControlArt(all,"Button_ShopTrail","Speed",UpgradeSpeed);
        foreach(Transform t in all)
        {
            if(t.name=="[Button] Steal")
            {
                Image source=t.GetComponent<Image>();if(source && source.sprite){actionButton.GetComponent<Image>().sprite=source.sprite;actionButton.GetComponent<Image>().type=source.type;actionButton.GetComponent<Image>().color=Color.white;}
            }
        }
        Destroy(art);
        // Source artwork is reused without the full game's framework components.
        panel.transform.SetAsLastSibling();endCard.transform.SetAsLastSibling();
    }
    private void CopyControlArt(Transform[] all,string sourceName,string targetName,UnityEngine.Events.UnityAction action)
    {
        foreach(Transform t in all)if(t.name==sourceName)
        {
            RectTransform target=(RectTransform)safeUI.Find(targetName);
            t.SetParent(safeUI,false);Place((RectTransform)t,target.anchorMin,target.anchorMax);t.gameObject.SetActive(true);
            Button b=t.GetComponent<Button>();if(!b)b=t.gameObject.AddComponent<Button>();b.onClick=new Button.ButtonClickedEvent();b.onClick.AddListener(action);
            if(targetName=="Speed")foreach(TMPro.TMP_Text label in t.GetComponentsInChildren<TMPro.TMP_Text>(true))label.text="Speed +";
            target.gameObject.SetActive(false);return;
        }
    }
    private void Place(RectTransform rt,Vector2 min,Vector2 max){rt.anchorMin=min;rt.anchorMax=max;rt.offsetMin=Vector2.zero;rt.offsetMax=Vector2.zero;rt.localScale=Vector3.one;}
    private void OpenPanel(string mode)
    {
        panel.SetActive(true);joystick.ResetInput();panelTitle.text=mode;
        panelBody.text=mode=="PETS"?pets.Count+" PETS\nIncome: $"+(pets.Count*5)+" / second":mode=="SHOP"?"Earn coins by hatching eggs.\nSpeed upgrade: 100 coins":"";
        panelBody.gameObject.SetActive(mode!="MAP");
        foreach(Transform child in panel.transform)if(child.name.StartsWith("Zone_"))child.gameObject.SetActive(mode=="MAP");panel.transform.Find("MenuInstall").gameObject.SetActive(mode!="MAP");
    }
    private void UpdateSafeArea(){if(Screen.width==0 || Screen.height==0)return;UnityEngine.Rect s=Screen.safeArea;safeUI.anchorMin=new Vector2(s.xMin/Screen.width,s.yMin/Screen.height);safeUI.anchorMax=new Vector2(s.xMax/Screen.width,s.yMax/Screen.height);}
    private RectTransform Rect(string name,Transform parent,Vector2 min,Vector2 max)
    {RectTransform rt=new GameObject(name,typeof(RectTransform)).GetComponent<RectTransform>();rt.SetParent(parent,false);rt.anchorMin=min;rt.anchorMax=max;rt.offsetMin=Vector2.zero;rt.offsetMax=Vector2.zero;return rt;}
    private RectTransform Box(string name,Transform parent,Vector2 min,Vector2 max,Color color)
    {RectTransform rt=Rect(name,parent,min,max);Image image=rt.gameObject.AddComponent<Image>();image.color=color;image.sprite=roundedSprite;image.type=Image.Type.Sliced;return rt;}
    private Text Label(string name,Transform parent,string value,int size,Vector2 min,Vector2 max)
    {
        RectTransform rt=Rect(name,parent,min,max);Text t=rt.gameObject.AddComponent<Text>();t.font=uiFont;t.text=value;t.fontSize=size;t.color=Color.white;t.alignment=TextAnchor.MiddleCenter;t.raycastTarget=false;t.resizeTextForBestFit=true;t.resizeTextMinSize=11;t.resizeTextMaxSize=size;
        Outline o=rt.gameObject.AddComponent<Outline>();o.effectColor=new Color(0,0,0,.7f);o.effectDistance=new Vector2(1,-1);return t;
    }
    private Button ButtonText(string name,Transform parent,string value,Vector2 min,Vector2 max,UnityEngine.Events.UnityAction click)
    {RectTransform rt=Box(name,parent,min,max,new Color(.12f,.39f,.76f,.98f));Button b=rt.gameObject.AddComponent<Button>();b.onClick.AddListener(click);Label("Label",rt,value,24,new Vector2(.04f,.05f),new Vector2(.96f,.95f));return b;}
}
