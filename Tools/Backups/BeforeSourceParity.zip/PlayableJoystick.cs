using UnityEngine;
using UnityEngine.EventSystems;

public class PlayableJoystick : MonoBehaviour, IPointerDownHandler, IDragHandler, IPointerUpHandler
{
    public RectTransform knob;
    public Vector2 Value {get;private set;}
    private int pointerId=int.MinValue;
    public void OnPointerDown(PointerEventData e){if(pointerId!=int.MinValue)return;pointerId=e.pointerId;OnDrag(e);}
    public void OnDrag(PointerEventData e)
    {
        if(e.pointerId!=pointerId)return;RectTransform area=(RectTransform)transform;Vector2 point;
        if(RectTransformUtility.ScreenPointToLocalPointInRectangle(area,e.position,e.pressEventCamera,out point))
        {float radius=Mathf.Min(area.rect.width,area.rect.height)*.4f;Value=Vector2.ClampMagnitude(point/radius,1);knob.anchoredPosition=Value*radius;}
    }
    public void OnPointerUp(PointerEventData e){if(e.pointerId==pointerId)ResetInput();}
    public void ResetInput(){pointerId=int.MinValue;Value=Vector2.zero;if(knob)knob.anchoredPosition=Vector2.zero;}
    private void OnDisable(){ResetInput();}
}
